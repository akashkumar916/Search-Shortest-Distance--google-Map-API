<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 
<script type="text/javascript">
//var loc=document.getElementById('location').value;

if(navigator.geolocation){

navigator.geolocation.getCurrentPosition(shown);
}function shown(positon){

var f="location:n"+position.coords.latitude+"longitude:"+position.coords.longitude;

}




var c=60;
function show(event){

   $('#alert2').show().text("Success! Your Order is Successfull from Your Location to nearest Hospital and same order was cancelled");
   
$('#alert3').show();


}
function cancel(){
$('#alert3').show();

}
function time(){

document.getElementById('map').style.display="block";

var c=60;

        var t;
        timedCount();
 
        function timedCount()
		{
 
        	var hours = parseInt( c / 3600 ) % 24;
        	var minutes = parseInt( c / 60 ) % 60;
        	var seconds = c % 60;
 
        	var result = (hours < 10 ? "0" + hours : hours) + ":" + (minutes < 10 ? "0" + minutes : minutes) + ":" + (seconds  < 10 ? "0" + seconds : seconds);
 
            
        	$('#timer').html(result);
		
            if(c == 0 )
			{
           $('#alert1').show();
		
				 $('#alert3').addClass('disabled');
			}
            c = c - 1;
            t = setTimeout(function()
			{
			 timedCount()
			},
			1000);
        }


}

function d(){


document.getElementById('table').style.display="block";

}



</script>

<style>
body{

background:url("6.jpg") no-repeat;
background-color:rgba(0,0,0,0.2);
background-size:cover;

}
#home1,#home{border-radius:10px;
border:3px solid black;
 background: linear-gradient(red,grey,white);

}
.nav, li:hover,li:active{

background-color:skyblue;

}
 table thead{
background-color:red;
color:black;}
#table1 tr{
 background: linear-gradient(orange,yellow);


}#table1{
border:3px solid black;
border-radius:8px;
}
#dvmap:hover{


box-shadow:5px 5px grey;
}

#table{
display:none;}
.alert{
display:none;}

input[type="text"]{

width:340px;

}

</style>
</head>
<body>


  <nav class="navbar navbar-expand-sm bg-secondary navbar-dark" style="height:50px">
    <a class="navbar-brand  font-weight-bold text-dark" href="" style="font-size:25px;">
Blood Bank</a>

  <ul class="navbar-nav" id="nav">
    <li class="nav-item active text-center">
      <a class="nav-link" href="#"><i class="fa fa-bars " style="font-size:25px;"></i></a>
    </li>
    <li class="nav-item  text-center">
      <a class="nav-link ml-4  text-center" href="#"><i class="fa fa-hospital-o " style="font-size:25px;"></i></a>
    </li>
    <li class="nav-item  text-center">
      <a class="nav-link ml-4" href="#"><i class="fa fa-address-card" style="font-size:25px;"></i></a>
    </li>
    <li class="nav-item">
      <a class="nav-link ml-4 " href="#"><i class="fa fa-user"style="font-size:25px;"></i></a>
    </li>
    <li class="nav-item dropdown">
      <a class="nav-link ml-4 dropdown-toggle" id="dropdown" data-toggle="dropdown" href="#"><i class="fa fa-id-card-o " style="font-size:25px;"></i>
      <span class="badge badge-danger">new</span></a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="#">patient 1</a>
            <a class="dropdown-item" href="#">Id</a>
            <a class="dropdown-item" href="#">History</a>

      </div>

    </li>
    <li class="nav-item">
      <a class="nav-link ml-4 " href="#"><i class="fa fa-plus-square-o"style="font-size:25px;"></i></a>
    </li>
    <li class="nav-item">
      <a class="nav-link ml-4 " href="#"><i class="fa fa-handshake-o"style="font-size:25px;"></i></a>
    </li>

</ul>
 <img src="e.jpg" style="position:absolute;top:50px;left:950px;width:80px;height:80px";/>
<div class="container" id="card" style="width:600px;height:200px;position:absolute;top:300px;left:600px;">
<ul class="nav nav-tabs " style="background-color:white">
<li class="nav-item text-center" style="width:200px;"><a class="nav-link active " data-toggle="tab" href="#home">Sign up</a>
</li>
<li class="nav-item text-center" style="width:200px;"><a class="nav-link " data-toggle="tab" href="#home1">Emergency Case</a>
</li>
</ul>
<div class="tab-content bg-light" >
<div class="tab-pane active container p-3" id="home">
<form method="post" >
<div class="form-group">

<label for="name">Name:</label><input type="text" name="name" class="form-control"  required  id="name"/>
<label for="age">Age:</label><input type="text" name="name" class="form-control" required  id="age"/>

<label for="address">Current Location :</label><input type="text"  name="name" required class="form-control"   id="address"/>
<label for="blood">Blood Group:</label><input type="text" name="name" class="form-control" required   id="b"/>
<label for="location">Hospital Name with district :</label><input type="text" name="name"  required class="form-control" style="height:100px" id="location"/>
<button class="btn  btn-danger form-control mt-4" id="blood1" >Order Blood</button>

</div>
<div  class="alert alert-info alert-dismissible mt-5"  id="alert1">
  <button type="button" class="close" data-dismiss="alert">&times;</button>
  <strong>Success!</strong> Your Order is Successfull from Your Location to nearest Hospital
</div>
<div class="alert alert-danger alert-dismissible mt-5" id="alert3">
  <button type="button" class="close" data-dismiss="alert">&times;</button>
  <strong>Your </strong>  Order is Cancel Successfully
</div>
</form>

</div>
<div class="tab-pane bg-light container p-3" id="home1">
<form >
<div class="form-group">

<label for="name">Name:</label><input type="text" name="name"   class="form-control" id="name"/>
<label for="age">Age:</label><input type="text" name="name"  class="form-control" id="age"/>

<label for="address">Current Location :</label><input type="text"   name="name" class="form-control" id="address"/>
<label for="blood">Blood Group:</label><input type="text"   name="name" class="form-control" id="group"/>
<label for="location"> Hospital Name with district :</label><input type="text" name="name" class="form-control" style="height:100px" id="location"/>
<button class="btn  btn-danger form-control mt-4"  >Order Blood</button> 

</div>

</form>
<div class="alert alert-info alert-dismissible mt-5" id="alert2">
  <button type="button" class="close" data-dismiss="alert">&times;</button>
  <strong>Success!</strong> Your Order is Successfull from Your Location to nearest Hospital
</div>
</div>
</div>
</div>

<button id="boo" class="btn btn-block btn-danger text-dark ml-auto" style="width:500px;color:white;" onclick="d()">Find Blood near my Location</button>



<!--<p  style="position:absolute;left:100px;top:80px;color:black;" >Timing:<span id="timer"></span></p>-->
<div class="container" style="position:absolute;left:70px;top:180px;width:500px;" id="table">
<div><h2 class="h2 "  style="color:black">Blood Bank in Your City</h2><div>
<table class="table table-striped table-hover " style="cellpadding:2px" style="border-style:double" id="table1">

<thead class="table-dark" style="color:black">
<tr>
<th>Blood Type</th>
<th>No. of Sample</th>
<th>Blood Bank Name</th>
</tr>
</thead>

<tr>
<td>A+</td>
<td>275</td>
<td>Sacred Heart Hospital</td>
</tr>

<tr>
<td>O-</td>
<td id="neg" value=5>5</td>
<td>Kidney Hospital</td>
</tr>
<tr>
<td>O+</td>
<td>225</td>
<td>SGL Charitable Hospital</td>
</tr>
<tr>
<td>B-</td>
<td>425</td>
<td>SilverOaks Hospital</td>
</tr>
<tr>
<td>B+</td>
<td>615</td>
<td>Khan Blood Bank</td>
</tr>
<tr>
<td>AB+</td>
<td>125</td>
<td>yujI Blood Bank</td>
</tr>


</table>

</div><section class="bg-light" style="bg-Color:white;">
<div class="text-center" style="position:absolute;border:2px solid black;top:570px;left:50px;" id="map">
<table class="table "border="0" cellpadding="0" cellspacing="3" style="background-color:skyblue;">
<tr>
    <td colspan="2">
     
        <input type="hidden" id="txtSource"  class="ml-5 mt-3" value="Lpu,Jalandhar, India" style="width: 400px" />
        &nbsp; Blood Bank Name with state:
        <input type="text" id="txtDestination" class="mt-3"  value="phagwara,punjab, India" style="width: 500px" />
        <br />
       <button class="btn btn-danger ml-5 mt-3" value="Get Route"  onclick="GetRoute()" >Get Route</button>
        <hr />
    </td>
</tr>
<tr>
    <td colspan="2">
        <div id="dvDistance">
		<h1 class="h2" >Nearest Path from Your Location</h1>
        </div>
    </td>
</tr>
<tr>
    <td>
        <div id="dvMap" style="width: 700px; box-shadow:5px 5px 4px grey;border:1px solid black;height: 600px;margin-left:-50px;">
        </div>
    </td>
    <td>
        <div id="dvPanel"  style="width: 400px; height: 200px;margin-top:-100px;">
        </div>
    </td>
</tr>
</table></div></section>
<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false&libraries=places"></script>
<script type="text/javascript">
var source, destination;
var directionsDisplay;
var directionsService = new google.maps.DirectionsService();
google.maps.event.addDomListener(window, 'load', function () {
    new google.maps.places.SearchBox(document.getElementById('txtSource'));
    new google.maps.places.SearchBox(document.getElementById('txtDestination'));
    directionsDisplay = new google.maps.DirectionsRenderer({ 'draggable': true });
});
 
function GetRoute() {
    var mumbai = new google.maps.LatLng(31.1471,  75.3412);
    var mapOptions = {
        zoom: 9,
        center: mumbai
    };
    map = new google.maps.Map(document.getElementById('dvMap'), mapOptions);
    directionsDisplay.setMap(map);
    directionsDisplay.setPanel(document.getElementById('dvPanel'));
 
    //*********DIRECTIONS AND ROUTE**********************//
    source = document.getElementById("txtSource").value;
    destination = document.getElementById("txtDestination").value;
 
    var request = {
        origin: source,
        destination: destination,
        travelMode: google.maps.TravelMode.DRIVING
    };
    directionsService.route(request, function (response, status) {
        if (status == google.maps.DirectionsStatus.OK) {
            directionsDisplay.setDirections(response);
        }
    });
 
    //*********DISTANCE AND DURATION**********************//
    var service = new google.maps.DistanceMatrixService();
    service.getDistanceMatrix({
        origins: [source],
        destinations: [destination],
        travelMode: google.maps.TravelMode.DRIVING,
        unitSystem: google.maps.UnitSystem.METRIC,
        avoidHighways: false,
        avoidTolls: false
    }, function (response, status) {
        if (status == google.maps.DistanceMatrixStatus.OK && response.rows[0].elements[0].status != "ZERO_RESULTS") {
            var distance = response.rows[0].elements[0].distance.text;
            var duration = response.rows[0].elements[0].duration.text;
            var dvDistance = document.getElementById("dvDistance");
           dvDistance.innerHTML = "";
            dvDistance.innerHTML += "Distance: " + distance + "<br />";
            dvDistance.innerHTML += "Duration:" + duration;
 
        } else {
            alert("Unable to find the distance via road.");
        }
    });
}
</script>


</body>
</html>